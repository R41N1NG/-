/* ═══════════════════════════════════════════════════════════
 * 十四 · 启动自检
 * ═══════════════════════════════════════════════════════════ */
XSD_DISPATCHER.scheduleStart(() => {
  try {
    console.log(TAG, `── 启动自检 ${VERSION} ──（下面那行「[初始化·启动]」是本版新增的账本心跳：`
      + '看到「字段齐全」或「✅ 已落地」都算正常；看到「❌ 变量没写进去」就是账本没落地）');
  } catch (e) { /* 忽略 */ }
  xsdWho();
});

console.log(TAG, `${VERSION} 已加载。命令：/已知 · /锚点 · /解锁 <字段> · /回锁 <字段> · /身份 [名字] · /刷新开场白；`
  + '第 0 楼的身份菜单可点击；控制台可调 __xsdWho() / __xsdDump() / __xsdBoot()；'
  + '渲染触发入口 window.__xsdStateTick(mesid, rawText)；控制台调试：__xsdStateTick(1, "<Status_block>…</Status_block>")。');
