/**
 * @module okh_app_migrate
 * @updated 2026-11-18 21:08
 * @status  active
 * @reason  存档版本幂等迁移（升级至 schemaVersion=3）：补全 playerState.inventory、supply_shortage 及进行中剧情证物，并保护既有 custom:true 外部条目
 * @deps    OKH_APP_DATA
 * @provides { LEGACY_KEYS, migrateWorld }
 */
(function (root) {
  'use strict'

  const DATA = root.OKH_APP_DATA
  if (!DATA) throw Error('migrate 缺少 OKH_APP_DATA')

  const LEGACY_KEYS = [
    'pride', 'duty', 'lust', 'fear', 'shame', 'need',
    'curiosity', 'loyalty', 'corruption', 'sanity', 'exposure', 'isolation'
  ]

  function normalizeActivityOnMigrate(npc, timeMin, reportList) {
    if (!npc.activity) {
      npc.activity = null
      return
    }
    if (npc.activity.startedAt > timeMin) npc.activity.startedAt = timeMin
    const prevRule = npc.activity.releaseRule
    if (prevRule !== undefined && prevRule !== 'manualRelease') {
      if (npc.activity.kind === 'important' || npc.activity.kind === 'special') {
        npc.activity.migratedFromReleaseRule = prevRule
        npc.activity.releaseRule = 'manualRelease'
        reportList.push({
          npcId: npc.id,
          activityId: npc.activity.id,
          label: npc.activity.label || npc.activity.kind,
          fromReleaseRule: prevRule,
          toReleaseRule: 'manualRelease'
        })
      } else {
        delete npc.activity.releaseRule
      }
    }
  }

  function migrateNpcFromRoster(existing, tpl, inferredArrived, timeMin, reportList, worldFlags) {
    if (!existing) {
      const fresh = JSON.parse(JSON.stringify(tpl))
      if (inferredArrived) {
        if (fresh.location === 'wilds' && tpl.homeLocation) fresh.location = tpl.homeLocation
        if (tpl.id === 'ed') fresh.monitored = true
      }
      return fresh
    }

    const next = JSON.parse(JSON.stringify(existing))
    next.hasStage = tpl.hasStage
    next.hasAffection = tpl.hasAffection
    next.homeLocation = tpl.homeLocation
    next.plan = tpl.plan.slice()
    next.nodePlan = tpl.hasStage ? tpl.nodePlan.slice() : []
    next._metricBounds = { ...tpl._metricBounds }
    next.flags ||= {}
    next.nodeStates ||= {}
    next.activityHistory ||= {}
    if (tpl.id === 'eileen' && !worldFlags?.eileen_arrived && !next.flags.eileen_fugitive && !next.flags.eileen_captured) {
      next.monitored = false
    }
    if (!Object.hasOwn(DATA.LOCATIONS, next.location)) next.location = tpl.location

    const cleanValues = {}
    for (const [k, defVal] of Object.entries(tpl.values)) {
      const oldVal = next.values?.[k]
      cleanValues[k] = Number.isFinite(oldVal) ? oldVal : defVal
    }
    for (const k of LEGACY_KEYS) {
      if (!Object.hasOwn(tpl.values, k)) delete cleanValues[k]
    }
    next.values = cleanValues
    if (tpl.id === 'aurora' && cleanValues.debt_pressure === 0 &&
        !next.flags.aurora_evt3_done && !next.flags.aurora_debt_cleared) {
      cleanValues.debt_pressure = tpl.values.debt_pressure
    }
    if (tpl.id === 'cecilia' && cleanValues.orphanage_funds === 0 &&
        existing.flags?.lastNightSettledDay === undefined &&
        !next.flags.cecilia_evt1_done && !next.flags.cecilia_midgame_crisis && (next.stage ?? 0) === 0) {
      cleanValues.orphanage_funds = tpl.values.orphanage_funds
    }
    next._baseline = { ...cleanValues }

    if (tpl.hasStage === false) {
      delete next.stage
    } else {
      next.stage ??= 0
      if (tpl.id === 'gulan') {
        for (const idx of [1, 2, 3]) {
          if (next.nodeStates['stage_' + idx] && !next.nodeStates['gulan_stage_' + idx]) {
            next.nodeStates['gulan_stage_' + idx] = next.nodeStates['stage_' + idx]
            delete next.nodeStates['stage_' + idx]
          }
        }
      }
    }

    if (tpl.hasAffection !== false && tpl.hasStage !== false && (next.stage ?? 0) >= 3) {
      if (Object.hasOwn(next.values, 'affection')) {
        next.values.affection = Math.min(next.values.affection, 50)
      }
      next.flags.affection_locked = true
    }

    normalizeActivityOnMigrate(next, timeMin, reportList)
    delete next._lines
    return next
  }

  function migratePendingQueueToEventStates(world) {
    world.bg.eventStates ||= {}
    for (const entry of world.bg.queue || []) {
      if (
        entry &&
        entry.kind === 'event' &&
        entry.mode === 'interaction' &&
        (entry.status === 'pending' || entry.status === 'delivered') &&
        entry.id &&
        !Object.hasOwn(world.bg.eventStates, entry.id)
      ) {
        world.bg.eventStates[entry.id] = {
          status: 'pending',
          definitionId: entry.definitionId,
          npcId: entry.npcId ?? null,
          triggeredAt: entry.at ?? world.timeMin
        }
      }
    }
  }

  function migrateWorld(rawWorld) {
    if (!rawWorld) return rawWorld
    if ((rawWorld.schemaVersion ?? 1) >= DATA.SCHEMA_VERSION) return rawWorld

    const world = JSON.parse(JSON.stringify(rawWorld))
    const timeMin = Number.isSafeInteger(world.timeMin) ? world.timeMin : 0
    const inferredArrived =
      world.schemaVersion === undefined &&
      (world.playerLocation === 'inn' || Object.values(world.npcs || {}).some(n => n.location === 'inn'))

    world.flags ||= {}
    if (world.flags.arrived_oakhaven === undefined) world.flags.arrived_oakhaven = inferredArrived
    if (world.flags.arrivedDay === undefined) {
      world.flags.arrivedDay = world.flags.arrived_oakhaven ? 1 : null
    }
    if (world.flags.ed_joined === undefined) world.flags.ed_joined = inferredArrived
    if (world.flags.playerRoomTarget === undefined) world.flags.playerRoomTarget = null
    for (const flagKey of [
      'inn_arrears', 'supply_shortage', 'orc_camp_bounty_paid', 'lancaster_purge_reward_paid',
      'eileen_arrived', 'eileen_departed', 'eileen_fugitive', 'eileen_signal_fired', 'baron_purged', 'player_barony_granted'
    ]) {
      if (world.flags[flagKey] === undefined) world.flags[flagKey] = false
    }
    if (world.flags.lastInnSettledDay === undefined) world.flags.lastInnSettledDay = 0
    if (world.flags.playerOddJobDay === undefined) world.flags.playerOddJobDay = null
    if (world.flags.lastGuildCommissionDay === undefined) world.flags.lastGuildCommissionDay = null
    if (world.flags.lastChurchErrandDay === undefined) world.flags.lastChurchErrandDay = null
    world.playerState ||= {}
    if (!Number.isSafeInteger(world.playerState.gold) || world.playerState.gold < 0) {
      world.playerState.gold = world.flags.player_barony_granted ? 1000 : 40
    }
    delete world.playerState.injury
    if (!Array.isArray(world.playerState.inventory)) {
      // 老存档未建背包时，前传荒原途中补开局 10 份补给，已抵镇存档置空数组避免凭空生出补给
      world.playerState.inventory = world.flags.arrived_oakhaven ? [] : [{ id: 'supply', count: 10 }]
    }
    const ensureQuestItem = (itemId) => {
      if (!world.playerState.inventory.some(it => it && it.id === itemId)) {
        world.playerState.inventory.push({ id: itemId, count: 1 })
      }
    }
    if (world.flags.alice_evidence_secured && !world.flags.alice_rescued) {
      ensureQuestItem('alice_ledger')
    }
    if (world.npcs?.aurora?.flags?.aurora_eileen_intel_given && !world.flags.eileen_signal_fired && !world.flags.baron_purged) {
      ensureQuestItem('manor_intel_note')
    }
    if (world.flags.player_barony_granted) {
      ensureQuestItem('barony_patent')
    }
    if (!Object.hasOwn(DATA.LOCATIONS, world.playerLocation)) {
      world.playerLocation = inferredArrived ? 'inn' : 'wilds'
    }

    world.bg ||= { version: 2, revision: 0, receipts: {}, settled: {}, fired: {}, queue: [], generations: {} }
    migratePendingQueueToEventStates(world)

    const manualReleaseActivities = []
    const nextNpcs = {}
    for (const tpl of DATA.ROSTER) {
      nextNpcs[tpl.id] = migrateNpcFromRoster(world.npcs?.[tpl.id], tpl, inferredArrived, timeMin, manualReleaseActivities, world.flags)
    }
    world.npcs = nextNpcs
    world.bg.migrationReport = {
      fromSchemaVersion: rawWorld.schemaVersion ?? 1,
      toSchemaVersion: DATA.SCHEMA_VERSION,
      manualReleaseActivities
    }
    world.interactingIds = (world.interactingIds || []).filter(id => Object.hasOwn(nextNpcs, id))
    world.schemaVersion = DATA.SCHEMA_VERSION
    return world
  }

  root.OKH_APP_MIGRATE = Object.freeze({ LEGACY_KEYS, migrateWorld })

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = root.OKH_APP_MIGRATE
  }
})(typeof globalThis !== 'undefined' ? globalThis : this)
