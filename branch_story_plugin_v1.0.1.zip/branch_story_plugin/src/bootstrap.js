(function (root) {
  'use strict';
  if (!root.document || !root.BSECore || !root.BSEHost) return;
  const host = new root.BSEHost.Host(root);
  root.__branch_story_startup__ = {status: 'loading', error: ''};
  const start = async () => {
    root.__branch_story_plugin__?.destroy?.();
    const engine = new root.BSEEngine.Engine(host); const panel = new root.BSEUI.Panel(engine);
    const plugin = {engine, panel, open: () => panel.toggle(), getState: () => engine.snapshot(), submitEvent: (...args) => engine.manualEvent(...args), destroy: () => { panel.destroy(); engine.destroy(); }};
    root.__branch_story_plugin__ = plugin;
    root.addEventListener('pagehide', plugin.destroy, {once: true});
    panel.mount();
    try {
      if (!host.api('getVariables')) throw new Error('未找到酒馆助手 getVariables 接口，请确认酒馆助手已启用且脚本运行在酒馆助手中');
      await engine.init();
    } catch (e) {
      engine.settings.enabled = false; engine.error = e.message; panel.render(); throw e;
    }
    const name = '分支剧本面板';
    try {
      const update = host.api('updateScriptButtonsWith');
      if (update) update(buttons => {
        const button = buttons.find(b => b.name === name);
        if (button) button.visible = true; else buttons.push({name, visible: true});
        return buttons;
      });
      else host.api('appendInexistentScriptButtons')?.([{name, visible: true}]);
      const buttonEvent = host.api('getButtonEvent')?.(name); if (buttonEvent) host.on(buttonEvent, buttonEvent, () => panel.toggle());
    } catch (e) { console.warn('[BSE] 面板快捷按钮注册失败', e.message); }
    const parser = host.owners().find(o => o.SlashCommandParser)?.SlashCommandParser;
    const command = host.owners().find(o => o.SlashCommand)?.SlashCommand;
    if (parser?.addCommandObject && command?.fromProps) {
      try { parser.addCommandObject(command.fromProps({name: 'bse', callback: () => { panel.toggle(); return ''; }, helpString: '打开分支剧本面板'})); } catch {}
    }
    root.__branch_story_startup__.status = 'ready'; return plugin;
  };
  root.__branch_story_ready__ = (host.doc()?.body ? Promise.resolve() : new Promise(resolve => root.addEventListener('DOMContentLoaded', resolve, {once: true}))).then(start);
  root.__branch_story_ready__.catch(e => {
    root.__branch_story_startup__ = {status: 'error', error: e.message || String(e)};
    console.error('[BSE] 初始化失败：' + root.__branch_story_startup__.error);
    const toast = host.owners().find(o => o.toastr?.error)?.toastr;
    try { toast?.error(root.__branch_story_startup__.error, '分支剧本启动失败'); } catch {}
  });
})(typeof window !== 'undefined' ? window : globalThis);
